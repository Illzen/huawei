#!/usr/bin/env node

export default {
    data: {
        title: 'World'
    },
    clickAction() {
        console.log("I am CLICKED!");
    }
}
